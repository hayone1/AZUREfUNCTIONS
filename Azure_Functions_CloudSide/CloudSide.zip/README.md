# AZUREfUNCTIONS_CloudSide
The repo contains the c# functions used within the Azure cloud to realize the Final year IoT project
